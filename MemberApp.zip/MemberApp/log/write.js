var fs = require('fs');
fs.appendFile('sample.html', 'Hello World!', function (err) {
if (err)
console.log(err);
else
console.log('Write operation complete.');
});

const member = [
    {
        id: 1,
        name: 'mahima',
        email: 'mahi@gmail.com',
        status: 'active'
      },

      {
        id: 1,
        name: 'ankita',
        email: 'ankita@gmail.com',
        status: 'active'
      },

      {
        id: 1,
        name: 'ayush',
        email: 'aayush@gmail.com',
        status: 'active'
      },

      {
        id: 1,
        name: 'shreyas',
        email: 'shreyas@gmail.com',
        status: 'active'
      },
     
      
]

module.exports=member;

